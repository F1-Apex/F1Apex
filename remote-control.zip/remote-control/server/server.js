const WebSocket = require('ws');
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 8080;
const SECRET = process.env.SECRET || 'changeme-secret-key';

const server = http.createServer((req, res) => {
  if (req.method === 'GET' && req.url === '/') {
    const dashPath = path.join(__dirname, '../dashboard/index.html');
    if (fs.existsSync(dashPath)) {
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(fs.readFileSync(dashPath));
    } else {
      res.writeHead(404);
      res.end('Dashboard not found. Place dashboard/index.html next to server/');
    }
    return;
  }
  res.writeHead(404);
  res.end();
});

const wss = new WebSocket.Server({ server });

const agents = new Map();      // agentId -> ws
const controllers = new Map(); // ws -> agentId (selected)

function send(ws, data) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data));
}

wss.on('connection', (ws, req) => {
  console.log(`[+] Connection from ${req.socket.remoteAddress}`);

  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }

    if (msg.type === 'agent_register') {
      if (msg.secret !== SECRET) { send(ws, { type: 'error', message: 'Invalid secret' }); ws.close(); return; }
      const agentId = msg.agentId || crypto.randomUUID();
      agents.set(agentId, ws);
      ws._agentId = agentId;
      ws._role = 'agent';
      ws._hostname = msg.hostname || agentId;
      send(ws, { type: 'registered', agentId });
      console.log(`[agent] Registered: ${agentId} (${ws._hostname})`);
      notifyAgentList();
      return;
    }

    if (msg.type === 'controller_auth') {
      if (msg.secret !== SECRET) { send(ws, { type: 'error', message: 'Invalid secret' }); ws.close(); return; }
      ws._role = 'controller';
      controllers.set(ws, null);
      send(ws, { type: 'auth_ok', agents: getAgentList() });
      console.log(`[ctrl] Controller connected`);
      return;
    }

    if (msg.type === 'select_agent' && ws._role === 'controller') {
      controllers.set(ws, msg.agentId);
      send(ws, { type: 'agent_selected', agentId: msg.agentId });
      return;
    }

    if (ws._role === 'controller') {
      const targetId = controllers.get(ws);
      if (!targetId) { send(ws, { type: 'error', message: 'No agent selected' }); return; }
      const agentWs = agents.get(targetId);
      if (!agentWs || agentWs.readyState !== WebSocket.OPEN) { send(ws, { type: 'error', message: 'Agent offline' }); return; }
      agentWs.send(JSON.stringify(msg));
      return;
    }

    if (ws._role === 'agent') {
      for (const [cws, targetId] of controllers) {
        if (targetId === ws._agentId) send(cws, msg);
      }
      return;
    }
  });

  ws.on('close', () => {
    if (ws._role === 'agent') {
      agents.delete(ws._agentId);
      console.log(`[agent] Disconnected: ${ws._agentId}`);
      notifyAgentList();
    } else if (ws._role === 'controller') {
      controllers.delete(ws);
    }
  });
});

function getAgentList() {
  return [...agents.entries()].map(([id, ws]) => ({ id, hostname: ws._hostname }));
}

function notifyAgentList() {
  const list = getAgentList();
  for (const [cws] of controllers) send(cws, { type: 'agent_list', agents: list });
}

server.listen(PORT, () => {
  console.log(`\n✅ Server running → http://localhost:${PORT}`);
  console.log(`   Secret: ${SECRET}\n`);
});
