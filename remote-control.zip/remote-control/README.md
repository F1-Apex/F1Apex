# RemoteCtrl — Self-Hosted Remote Desktop

Control Windows machines from any browser over the internet.

## Architecture

```
[Browser Dashboard] ←→ [Relay Server] ←→ [Windows Agent]
```

- **Relay Server** — Node.js WebSocket hub. Runs on your server/VPS.
- **Agent** — Python script on each Windows PC. Handles screenshots, clicks, keypresses, code execution.
- **Dashboard** — Browser UI served by the relay server.

---

## 1. Set Up the Server

### Option A — Docker (recommended)

```bash
# Edit the SECRET in docker-compose.yml first!
cd server/
docker-compose up -d
```

### Option B — Node directly

```bash
cd server/
npm install
SECRET=your-secret-key node server.js
```

The server runs on port **8080** by default.
Open `http://your-server-ip:8080` to access the dashboard.

---

## 2. Install Agent on Windows PCs

Copy the `agent/` folder to each Windows machine, then:

1. Double-click **`install.bat`**
2. Enter your server's address: `ws://your-server-ip:8080`
3. Enter the same secret key you set on the server
4. Choose whether to auto-start on login

That's it. The agent will connect and appear in the dashboard.

---

## 3. Use the Dashboard

1. Open `http://your-server-ip:8080` in any browser
2. Enter the server URL and secret key → Connect
3. Select a connected agent from the left sidebar
4. Click **Screenshot** or **▶ Stream** to see the screen
5. **Click** anywhere on the screen to send clicks
6. Use the **text bar** at the bottom to type text
7. Use the **Code Runner** panel to execute Python/PowerShell/CMD

### Keyboard shortcuts
| Key | Action |
|-----|--------|
| F5 | Take screenshot |
| T | Toggle type mode |
| Ctrl+C | Send Ctrl+C to agent |
| Ctrl+V | Send Ctrl+V to agent |

---

## Security

> ⚠️ **Change the default secret key** before deployment.

- All connections require the shared secret key
- Run behind a reverse proxy (nginx/Caddy) with HTTPS for production
- Consider IP allowlisting at the firewall level for the server port

### HTTPS Setup (nginx example)

```nginx
server {
    listen 443 ssl;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:8080;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
```

Then use `wss://your-domain.com` as the server URL.

---

## Configuration

### Server environment variables
| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `8080` | Port to listen on |
| `SECRET` | `changeme-secret-key` | Shared authentication secret |

### Agent environment variables
| Variable | Description |
|----------|-------------|
| `RC_SERVER` | Server WebSocket URL |
| `RC_SECRET` | Shared secret |
| `RC_AGENT_ID` | Optional fixed agent ID |

---

## File Structure

```
remote-control/
├── server/
│   ├── server.js          ← Relay server
│   ├── package.json
│   ├── Dockerfile
│   └── docker-compose.yml
├── agent/
│   ├── agent.py           ← Windows agent
│   └── install.bat        ← Auto-installer
└── dashboard/
    └── index.html         ← Web dashboard
```
