"""
Remote Control Agent for Windows
"""

import asyncio
import websockets
import json
import base64
import io
import subprocess
import sys
import os
import uuid
import socket
import logging

logging.basicConfig(level=logging.INFO, format='[%(levelname)s] %(message)s')
log = logging.getLogger(__name__)

SERVER_URL = os.environ.get('RC_SERVER', 'ws://localhost:8080')
SECRET     = os.environ.get('RC_SECRET', 'changeme-secret-key')
AGENT_ID   = os.environ.get('RC_AGENT_ID', str(uuid.uuid4()))
HOSTNAME   = socket.gethostname()

try:
    import pyautogui
    import PIL.Image
    pyautogui.FAILSAFE = False
    HAS_GUI = True
except ImportError:
    HAS_GUI = False
    log.warning("pyautogui/pillow not installed")


def take_screenshot() -> str:
    if not HAS_GUI:
        return ""
    img = pyautogui.screenshot()
    buf = io.BytesIO()
    img.convert("RGB").save(buf, format="JPEG", quality=60)
    return base64.b64encode(buf.getvalue()).decode()


def do_click(x, y, button="left", double=False):
    if not HAS_GUI: return
    if double:
        pyautogui.doubleClick(x, y, button=button)
    else:
        pyautogui.click(x, y, button=button)


def do_move(x, y):
    if not HAS_GUI: return
    pyautogui.moveTo(x, y)


def do_scroll(x, y, clicks):
    if not HAS_GUI: return
    pyautogui.scroll(clicks, x=x, y=y)


def do_keypress(keys):
    if not HAS_GUI: return
    if len(keys) == 1:
        pyautogui.press(keys[0])
    else:
        pyautogui.hotkey(*keys)


def do_type(text):
    if not HAS_GUI: return
    pyautogui.typewrite(text, interval=0.02)


def run_code(code, lang="python"):
    try:
        if lang == "python":
            result = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, timeout=30)
        elif lang == "powershell":
            result = subprocess.run(["powershell", "-NoProfile", "-Command", code], capture_output=True, text=True, timeout=30)
        elif lang == "cmd":
            result = subprocess.run(code, shell=True, capture_output=True, text=True, timeout=30)
        else:
            return {"stdout": "", "stderr": f"Unsupported language: {lang}", "returncode": 1}
        return {"stdout": result.stdout, "stderr": result.stderr, "returncode": result.returncode}
    except subprocess.TimeoutExpired:
        return {"stdout": "", "stderr": "Timeout (30s)", "returncode": -1}
    except Exception as e:
        return {"stdout": "", "stderr": str(e), "returncode": -1}


async def handle_command(ws, msg):
    cmd = msg.get("cmd")
    req_id = msg.get("reqId")

    if cmd == "screenshot":
        data = take_screenshot()
        await ws.send(json.dumps({"type": "screenshot", "reqId": req_id, "data": data}))
    elif cmd == "click":
        do_click(msg["x"], msg["y"], msg.get("button", "left"), msg.get("double", False))
        await ws.send(json.dumps({"type": "ack", "reqId": req_id, "cmd": "click"}))
    elif cmd == "move":
        do_move(msg["x"], msg["y"])
        await ws.send(json.dumps({"type": "ack", "reqId": req_id, "cmd": "move"}))
    elif cmd == "scroll":
        do_scroll(msg["x"], msg["y"], msg.get("clicks", 3))
        await ws.send(json.dumps({"type": "ack", "reqId": req_id, "cmd": "scroll"}))
    elif cmd == "keypress":
        do_keypress(msg["keys"])
        await ws.send(json.dumps({"type": "ack", "reqId": req_id, "cmd": "keypress"}))
    elif cmd == "type":
        do_type(msg["text"])
        await ws.send(json.dumps({"type": "ack", "reqId": req_id, "cmd": "type"}))
    elif cmd == "run_code":
        result = run_code(msg["code"], msg.get("lang", "python"))
        await ws.send(json.dumps({"type": "code_result", "reqId": req_id, **result}))
    elif cmd == "ping":
        await ws.send(json.dumps({"type": "pong", "reqId": req_id}))
    else:
        await ws.send(json.dumps({"type": "error", "reqId": req_id, "message": f"Unknown command: {cmd}"}))


async def run_agent():
    log.info(f"Agent ID : {AGENT_ID}")
    log.info(f"Hostname : {HOSTNAME}")
    log.info(f"Server   : {SERVER_URL}")
    log.info("Connecting...")

    retry_delay = 5

    while True:
        try:
            async with websockets.connect(
                SERVER_URL,
                ping_interval=20,
                ping_timeout=10,
                open_timeout=10
            ) as ws:
                retry_delay = 5  # reset on success

                await ws.send(json.dumps({
                    "type": "agent_register",
                    "secret": SECRET,
                    "agentId": AGENT_ID,
                    "hostname": HOSTNAME
                }))

                resp = json.loads(await ws.recv())
                if resp.get("type") != "registered":
                    log.error(f"Registration failed: {resp}")
                    await asyncio.sleep(5)
                    continue

                log.info(f"✅ Connected and registered!")

                async for raw in ws:
                    try:
                        msg = json.loads(raw)
                        if msg.get("type") == "command":
                            asyncio.create_task(handle_command(ws, msg))
                    except Exception as e:
                        log.error(f"Error handling message: {e}")

        except (websockets.exceptions.ConnectionClosed, OSError) as e:
            log.warning(f"Connection lost: {e}")
        except Exception as e:
            log.error(f"Error: {e}")

        log.info(f"Retrying in {retry_delay}s...")
        await asyncio.sleep(retry_delay)
        retry_delay = min(retry_delay * 2, 60)  # back off up to 60s


if __name__ == "__main__":
    # Print helpful diagnosis if server URL looks wrong
    if "YOUR_SERVER_IP" in SERVER_URL:
        log.error("❌ SERVER URL NOT SET. Edit install.bat and set SERVER_URL before running.")
        input("Press Enter to exit...")
        sys.exit(1)

    asyncio.run(run_agent())
