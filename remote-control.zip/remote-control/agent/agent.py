"""
Remote Control Agent for Windows
Connects to relay server and executes commands from the controller.

Requirements (auto-installed by install.bat):
  pip install websockets pyautogui pillow
"""

import asyncio
import websockets
import json
import base64
import io
import subprocess
import sys
import os
import uuid
import socket
import logging

logging.basicConfig(level=logging.INFO, format='[%(levelname)s] %(message)s')
log = logging.getLogger(__name__)

# ── Config ────────────────────────────────────────────────────────────────────
SERVER_URL = os.environ.get('RC_SERVER', 'ws://YOUR_SERVER_IP:8080')
SECRET     = os.environ.get('RC_SECRET', 'changeme-secret-key')
AGENT_ID   = os.environ.get('RC_AGENT_ID', str(uuid.uuid4()))
HOSTNAME   = socket.gethostname()
# ──────────────────────────────────────────────────────────────────────────────

try:
    import pyautogui
    import PIL.Image
    pyautogui.FAILSAFE = False
    HAS_GUI = True
except ImportError:
    HAS_GUI = False
    log.warning("pyautogui/pillow not installed – screenshot/mouse/keyboard disabled")


def take_screenshot() -> str:
    """Capture screen and return as base64 JPEG."""
    if not HAS_GUI:
        return ""
    img = pyautogui.screenshot()
    buf = io.BytesIO()
    img.convert("RGB").save(buf, format="JPEG", quality=60)
    return base64.b64encode(buf.getvalue()).decode()


def do_click(x: int, y: int, button: str = "left", double: bool = False):
    if not HAS_GUI:
        return
    if double:
        pyautogui.doubleClick(x, y, button=button)
    else:
        pyautogui.click(x, y, button=button)


def do_move(x: int, y: int):
    if not HAS_GUI:
        return
    pyautogui.moveTo(x, y)


def do_scroll(x: int, y: int, clicks: int):
    if not HAS_GUI:
        return
    pyautogui.scroll(clicks, x=x, y=y)


def do_keypress(keys: list):
    """Press a key or key combo, e.g. ['ctrl', 'c'] or ['enter']."""
    if not HAS_GUI:
        return
    if len(keys) == 1:
        pyautogui.press(keys[0])
    else:
        pyautogui.hotkey(*keys)


def do_type(text: str):
    if not HAS_GUI:
        return
    pyautogui.typewrite(text, interval=0.02)


def run_code(code: str, lang: str = "python") -> dict:
    """Execute code in a subprocess and return stdout/stderr."""
    try:
        if lang == "python":
            result = subprocess.run(
                [sys.executable, "-c", code],
                capture_output=True, text=True, timeout=30
            )
        elif lang == "powershell":
            result = subprocess.run(
                ["powershell", "-NoProfile", "-Command", code],
                capture_output=True, text=True, timeout=30
            )
        elif lang == "cmd":
            result = subprocess.run(
                code, shell=True,
                capture_output=True, text=True, timeout=30
            )
        else:
            return {"stdout": "", "stderr": f"Unsupported language: {lang}", "returncode": 1}

        return {
            "stdout": result.stdout,
            "stderr": result.stderr,
            "returncode": result.returncode
        }
    except subprocess.TimeoutExpired:
        return {"stdout": "", "stderr": "Timeout (30s)", "returncode": -1}
    except Exception as e:
        return {"stdout": "", "stderr": str(e), "returncode": -1}


async def handle_command(ws, msg: dict):
    cmd = msg.get("cmd")
    req_id = msg.get("reqId")

    if cmd == "screenshot":
        data = take_screenshot()
        await ws.send(json.dumps({
            "type": "screenshot",
            "reqId": req_id,
            "data": data
        }))

    elif cmd == "click":
        do_click(msg["x"], msg["y"], msg.get("button", "left"), msg.get("double", False))
        await ws.send(json.dumps({"type": "ack", "reqId": req_id, "cmd": "click"}))

    elif cmd == "move":
        do_move(msg["x"], msg["y"])
        await ws.send(json.dumps({"type": "ack", "reqId": req_id, "cmd": "move"}))

    elif cmd == "scroll":
        do_scroll(msg["x"], msg["y"], msg.get("clicks", 3))
        await ws.send(json.dumps({"type": "ack", "reqId": req_id, "cmd": "scroll"}))

    elif cmd == "keypress":
        do_keypress(msg["keys"])
        await ws.send(json.dumps({"type": "ack", "reqId": req_id, "cmd": "keypress"}))

    elif cmd == "type":
        do_type(msg["text"])
        await ws.send(json.dumps({"type": "ack", "reqId": req_id, "cmd": "type"}))

    elif cmd == "run_code":
        result = run_code(msg["code"], msg.get("lang", "python"))
        await ws.send(json.dumps({
            "type": "code_result",
            "reqId": req_id,
            **result
        }))

    elif cmd == "ping":
        await ws.send(json.dumps({"type": "pong", "reqId": req_id}))

    else:
        await ws.send(json.dumps({
            "type": "error",
            "reqId": req_id,
            "message": f"Unknown command: {cmd}"
        }))


async def run_agent():
    log.info(f"Agent ID : {AGENT_ID}")
    log.info(f"Hostname : {HOSTNAME}")
    log.info(f"Server   : {SERVER_URL}")

    while True:
        try:
            async with websockets.connect(SERVER_URL, ping_interval=20, ping_timeout=10) as ws:
                # Register
                await ws.send(json.dumps({
                    "type": "agent_register",
                    "secret": SECRET,
                    "agentId": AGENT_ID,
                    "hostname": HOSTNAME
                }))

                resp = json.loads(await ws.recv())
                if resp.get("type") != "registered":
                    log.error(f"Registration failed: {resp}")
                    await asyncio.sleep(5)
                    continue

                log.info(f"✅ Registered as {resp['agentId']}")

                async for raw in ws:
                    try:
                        msg = json.loads(raw)
                        if msg.get("type") == "command":
                            asyncio.create_task(handle_command(ws, msg))
                    except Exception as e:
                        log.error(f"Error handling message: {e}")

        except (websockets.exceptions.ConnectionClosed, OSError) as e:
            log.warning(f"Disconnected: {e}. Reconnecting in 5s...")
            await asyncio.sleep(5)
        except Exception as e:
            log.error(f"Unexpected error: {e}. Retrying in 10s...")
            await asyncio.sleep(10)


if __name__ == "__main__":
    asyncio.run(run_agent())
