@echo off
setlocal EnableDelayedExpansion

echo ============================================
echo   Remote Control Agent - Windows Installer
echo ============================================
echo.

:: Check for Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python not found. Please install Python 3.8+ from https://python.org
    echo         Make sure to check "Add Python to PATH" during install.
    pause
    exit /b 1
)

echo [OK] Python found
echo.

:: Install dependencies
echo [*] Installing Python dependencies...
python -m pip install --upgrade pip --quiet
python -m pip install websockets pyautogui pillow --quiet

if %errorlevel% neq 0 (
    echo [ERROR] Failed to install dependencies.
    pause
    exit /b 1
)

echo [OK] Dependencies installed
echo.

:: Prompt for server config
set /p SERVER_URL="Enter server WebSocket URL (e.g. ws://192.168.1.10:8080): "
set /p SECRET="Enter secret key: "

if "!SERVER_URL!"=="" set SERVER_URL=ws://localhost:8080
if "!SECRET!"=="" set SECRET=changeme-secret-key

:: Write config to run script
echo @echo off > run_agent.bat
echo set RC_SERVER=!SERVER_URL!>> run_agent.bat
echo set RC_SECRET=!SECRET!>> run_agent.bat
echo python "%~dp0agent.py">> run_agent.bat

echo [OK] Config saved to run_agent.bat
echo.

:: Offer to install as Windows startup task
set /p AUTOSTART="Install as startup task? (runs on login) [y/N]: "
if /i "!AUTOSTART!"=="y" (
    schtasks /create /tn "RemoteControlAgent" /tr "\"%~dp0run_agent.bat\"" /sc onlogon /rl highest /f >nul 2>&1
    if !errorlevel! equ 0 (
        echo [OK] Startup task created
    ) else (
        echo [WARN] Could not create startup task (try running as Administrator)
    )
)

echo.
echo ============================================
echo   Installation complete!
echo   Run run_agent.bat to start the agent.
echo ============================================
echo.

set /p STARTNOW="Start agent now? [Y/n]: "
if /i not "!STARTNOW!"=="n" (
    start "" "%~dp0run_agent.bat"
)

pause
