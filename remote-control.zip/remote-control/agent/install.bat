@echo off
setlocal EnableDelayedExpansion

echo ============================================
echo   Remote Control Agent - Auto Installer
echo ============================================
echo.

:: ── CONFIG - EDIT THESE BEFORE DISTRIBUTING ──────────────────────────────────
set SERVER_URL=ws://YOUR_SERVER_IP:8080
set SECRET=changeme-secret-key
:: ─────────────────────────────────────────────────────────────────────────────

:: Must run as admin for scheduled task
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [*] Requesting administrator privileges...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

:: ── Step 1: Python ────────────────────────────────────────────────────────────
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [*] Downloading Python 3.12...
    powershell -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.4/python-3.12.4-amd64.exe' -OutFile '%TEMP%\python_installer.exe'" >nul 2>&1

    echo [*] Installing Python silently...
    "%TEMP%\python_installer.exe" /quiet InstallAllUsers=1 PrependPath=1 Include_pip=1

    :: Refresh PATH
    for /f "tokens=*" %%i in ('powershell -Command "[System.Environment]::GetEnvironmentVariable(\"PATH\", \"Machine\")"') do set "PATH=%%i"
    set "PATH=!PATH!;%ProgramFiles%\Python312;%ProgramFiles%\Python312\Scripts"

    python --version >nul 2>&1
    if %errorlevel% neq 0 (
        echo [*] PATH not refreshed yet - using full path...
        set PYTHON="%ProgramFiles%\Python312\python.exe"
    ) else (
        set PYTHON=python
    )
) else (
    set PYTHON=python
    echo [OK] Python already installed
)

:: ── Step 2: Dependencies ──────────────────────────────────────────────────────
echo [*] Installing dependencies...
!PYTHON! -m pip install --upgrade pip --quiet --no-warn-script-location
!PYTHON! -m pip install websockets pyautogui pillow --quiet --no-warn-script-location
echo [OK] Dependencies installed

:: ── Step 3: Write agent config ────────────────────────────────────────────────
set INSTALL_DIR=%ProgramFiles%\RemoteControlAgent
mkdir "%INSTALL_DIR%" >nul 2>&1

copy /y "%~dp0agent.py" "%INSTALL_DIR%\agent.py" >nul

:: Write launcher with config baked in
(
echo @echo off
echo set RC_SERVER=%SERVER_URL%
echo set RC_SECRET=%SECRET%
echo !PYTHON! "%INSTALL_DIR%\agent.py"
) > "%INSTALL_DIR%\run_agent.bat"

echo [OK] Agent installed to %INSTALL_DIR%

:: ── Step 4: Add Windows Firewall exception ────────────────────────────────────
echo [*] Adding firewall exception...
netsh advfirewall firewall add rule name="RemoteControlAgent" dir=out action=allow program="!PYTHON!" enable=yes >nul 2>&1
echo [OK] Firewall rule added

:: ── Step 5: Register as startup task (runs silently at login) ─────────────────
echo [*] Registering startup task...
schtasks /delete /tn "RemoteControlAgent" /f >nul 2>&1
schtasks /create /tn "RemoteControlAgent" /tr "\"%INSTALL_DIR%\run_agent.bat\"" /sc onlogon /rl highest /f >nul 2>&1
echo [OK] Startup task registered

:: ── Step 6: Start agent now ───────────────────────────────────────────────────
echo [*] Starting agent...
start "" /b "%INSTALL_DIR%\run_agent.bat"

echo.
echo ============================================
echo   Done! Agent is running and will auto-start
echo   on every login.
echo.
echo   Server : %SERVER_URL%
echo   Secret : %SECRET%
echo ============================================
echo.
timeout /t 5
