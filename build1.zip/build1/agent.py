import asyncio, websockets, json, base64, io, subprocess, sys, os, uuid, socket

SERVER_URL = os.environ.get('RC_SERVER', 'ws://67.241.173.150:7777')
SECRET     = os.environ.get('RC_SECRET', 'mike')
AGENT_ID   = str(uuid.uuid4())
HOSTNAME   = socket.gethostname()

try:
    import pyautogui, PIL.Image
    pyautogui.FAILSAFE = False
    HAS_GUI = True
except ImportError:
    HAS_GUI = False

def screenshot():
    if not HAS_GUI: return ''
    buf = io.BytesIO()
    pyautogui.screenshot().convert('RGB').save(buf, format='JPEG', quality=60)
    return base64.b64encode(buf.getvalue()).decode()

def run_code(code, lang):
    try:
        if lang == 'python':   r = subprocess.run([sys.executable, '-c', code], capture_output=True, text=True, timeout=30)
        elif lang == 'powershell': r = subprocess.run(['powershell', '-NoProfile', '-Command', code], capture_output=True, text=True, timeout=30)
        else:                  r = subprocess.run(code, shell=True, capture_output=True, text=True, timeout=30)
        return {'stdout': r.stdout, 'stderr': r.stderr, 'returncode': r.returncode}
    except subprocess.TimeoutExpired: return {'stdout': '', 'stderr': 'Timeout', 'returncode': -1}
    except Exception as e:            return {'stdout': '', 'stderr': str(e), 'returncode': -1}

async def handle(ws, msg):
    cmd, rid = msg.get('cmd'), msg.get('reqId')
    if cmd == 'screenshot':
        await ws.send(json.dumps({'type': 'screenshot', 'reqId': rid, 'data': screenshot()}))
    elif cmd == 'click':
        if HAS_GUI:
            if msg.get('double'): pyautogui.doubleClick(msg['x'], msg['y'], button=msg.get('button','left'))
            else: pyautogui.click(msg['x'], msg['y'], button=msg.get('button','left'))
        await ws.send(json.dumps({'type': 'ack', 'reqId': rid}))
    elif cmd == 'scroll':
        if HAS_GUI: pyautogui.scroll(msg.get('clicks', 3), x=msg['x'], y=msg['y'])
        await ws.send(json.dumps({'type': 'ack', 'reqId': rid}))
    elif cmd == 'keypress':
        if HAS_GUI:
            keys = msg['keys']
            if len(keys) == 1: pyautogui.press(keys[0])
            else: pyautogui.hotkey(*keys)
        await ws.send(json.dumps({'type': 'ack', 'reqId': rid}))
    elif cmd == 'type':
        if HAS_GUI: pyautogui.typewrite(msg['text'], interval=0.02)
        await ws.send(json.dumps({'type': 'ack', 'reqId': rid}))
    elif cmd == 'run_code':
        res = run_code(msg['code'], msg.get('lang', 'python'))
        await ws.send(json.dumps({'type': 'code_result', 'reqId': rid, **res}))
    elif cmd == 'ping':
        await ws.send(json.dumps({'type': 'pong', 'reqId': rid}))

async def main():
    delay = 5
    while True:
        try:
            async with websockets.connect(SERVER_URL, ping_interval=20, ping_timeout=10, open_timeout=10) as ws:
                delay = 5
                await ws.send(json.dumps({'type': 'agent_register', 'secret': SECRET, 'agentId': AGENT_ID, 'hostname': HOSTNAME}))
                resp = json.loads(await ws.recv())
                if resp.get('type') != 'registered': await asyncio.sleep(5); continue
                async for raw in ws:
                    msg = json.loads(raw)
                    if msg.get('type') == 'command': asyncio.create_task(handle(ws, msg))
        except Exception:
            await asyncio.sleep(delay)
            delay = min(delay * 2, 60)

asyncio.run(main())
